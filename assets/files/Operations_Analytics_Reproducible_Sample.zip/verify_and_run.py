"""Reproduce the original Juniper Vale SQL output using only Python 3."""
import sqlite3,csv,pathlib,os,re
ROOT=pathlib.Path(__file__).resolve().parent
DB=sqlite3.connect(':memory:')
files=["FactServiceOrder","FactAppointment","FactWeeklyReporting","DimCustomer","DimDate","DimServiceType","DimTechnician","DimTerritory"]
for name in files:
    with (ROOT/f"{name}.csv").open(newline='',encoding='utf-8-sig') as f:
        data=csv.reader(f); cols=next(data)
        assert all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',col) for col in cols), cols
        DB.execute(f'CREATE TABLE "{name}" ('+', '.join(f'"{x}" TEXT' for x in cols)+')')
        DB.executemany(f'INSERT INTO "{name}" VALUES ('+','.join(['?']*len(cols))+')',data)
        print(name,DB.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0])
SQL=(ROOT/'Operations_Analytics_SQL.sql').read_text(encoding='utf-8')
parts=re.split(r'(?m)^-- ===== (Q\d\d_[^\n]+\.sql) =====\s*$',SQL)
assert len(parts)==21,len(parts)
out=ROOT/'generated_sql_outputs';out.mkdir(exist_ok=True)
for i in range(1,len(parts),2):
    filename,query=parts[i],parts[i+1].strip()
    cur=DB.execute(query); cols=[c[0] for c in cur.description]; rows=cur.fetchall()
    output=out/(filename.replace('.sql','.csv'))
    with output.open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(cols);writer.writerows(rows)
    gold=ROOT/'sql_outputs'/output.name
    with gold.open(newline='',encoding='utf-8-sig') as f: ref=list(csv.reader(f))
    with output.open(newline='',encoding='utf-8-sig') as f: got=list(csv.reader(f))
    if len(ref)!=len(got) or ref[0]!=got[0]: raise AssertionError(f'{filename}: shape or column mismatch, saved {len(ref)} produced {len(got)}')
    errors=0
    for a,b in zip(ref[1:],got[1:]):
        if len(a)!=len(b): errors+=1;continue
        for v,w in zip(a,b):
            if v==w:continue
            try:
                if abs(float(v)-float(w))<=1e-9:continue
            except (TypeError,ValueError):pass
            errors+=1
    if errors:print(f'{output.name}: {errors} value differences');raise AssertionError(output.name)
    print(f'{output.name}: PASS ({len(rows)} data rows)')
print('All 10 SQL queries reproduced from the original synthetic source data and agree with the stored outputs.')
