JUNIPER VALE | REPRODUCIBLE SQL SAMPLE
Independent fictional work sample using only synthetic records from the original project package.

This is a 1,800-service-order stratified EXCERPT from the original 45,140-order synthetic dataset, NOT the complete dataset. Four groups of 450 orders were deterministically sampled from Baseline, 30-Day, 60-Day and 90-Day. Matching appointments and original dimension/weekly-reporting tables are included. No real employee or client records are present.

The 10 SQL queries are unchanged from the original independent case study. Saved query outputs in this sample were recalculated from the included 1,800 records. They will differ from the full scenario 90-day KPI percentages in the public case-study PDF, by design.

HOW TO REPRODUCE:
1. Extract this ZIP into a folder.
2. Run: python verify_and_run.py (standard Python 3 only).
3. The script creates in-memory SQLite tables, executes all ten SQL queries, then verifies columns, row counts and values against sql_outputs/. If all pass, you have reproduced the public excerpt, not the entire simulation.

LIMITS:
A subset can prove query execution and structure but cannot independently reproduce the full-scenario aggregate figures. For the full scenario data, see the author's original source archive. No live deployment, client outcomes or production Power BI dashboard is claimed.
